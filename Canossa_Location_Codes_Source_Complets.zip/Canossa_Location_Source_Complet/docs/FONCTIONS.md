# Fonctions prévues pour Canossa Location

## Calendrier
Vue mensuelle des réservations, départs, retours, retards et impayés.

## Client
Nom, prénom, téléphone, e-mail, adresse, code postal, identité, permis et expiration du permis.

## Parc
Immatriculation, marque, modèle, statut, catégorie, capacité, tarif journalier, année et kilométrage.

## Contrat
Contrat de location avec la clause :
**SORTIE DU TERRITOIRE ALGÉRIEN INTERDITE SAUF AUTORISATION ÉCRITE DE CANOSSA LOCATION.**

Signature électronique prévue par e-mail.

## Paiement
Suivi des règlements, soldes, cautions et impayés.

## Retards
Tolérance configurable puis pénalité horaire automatique.

## Alertes
Contrôle technique, entretien, assurance, retours et impayés.

## État des lieux
Kilométrage, carburant, dégâts et photos au départ et au retour.

## Messagerie
Prévu : WhatsApp en priorité, puis Messenger et autres canaux via API officielles.

## Sécurité
Architecture multi-utilisateurs prévue : administrateur et utilisateurs.
