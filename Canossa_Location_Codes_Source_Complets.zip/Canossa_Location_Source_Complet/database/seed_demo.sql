-- Données de démonstration Canossa
-- À exécuter uniquement sur une base de test.

insert into public.client
(id, nom, prenom, telephone, email)
values
(14, 'CLIENT TEST', 'Canossa', '0000000000', 'test@example.com')
on conflict (id) do nothing;

insert into public.vehicule
(id, immatriculation, marque, modele, statut, actif, categorie, capacite, tarif_journalier, annee, kilometrage)
values
(1, 'TEST-001', 'Peugeot', '308', 'disponible', true, 'Voiture', 5, 8000, 2022, 75000)
on conflict (id) do nothing;

insert into public.location
(id, client_id, vehicule_id, date_debut, date_fin, tarif_journalier, statut, note)
values
(13, 14, 1, '2026-09-23 09:00:00+00', '2026-09-30 09:00:00+00', 8000, 'en cours', 'Donnée de test')
on conflict (id) do nothing;
